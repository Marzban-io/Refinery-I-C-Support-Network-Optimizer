from .abstract_solver import AbstractSolver
import numpy as np
import gurobipy as gp
from gurobipy import GRB

class solver_344864_336623_337876(AbstractSolver):
    def __init__(self, env):
        super().__init__(env)
        self.name = 'solver_344864_336623_337876'

    def solve(self):
        # just a formality—AbstractSolver.solve() is a no-op
        super().solve()

        inst       = self.env.inst
        weights    = inst.weights
        service    = inst.service     # shape (n_depots, n_customers)
        distances  = inst.distances   # shape (n_depots+1, n_depots+1)

        n_depots, n_customers = service.shape
        nodes = range(n_depots + 1)   # 0 = company, 1..n_depots = warehouses

        # --- build model ---
        model = gp.Model(self.name)
        model.setParam('OutputFlag', 0)

        # decision vars
        X = model.addVars(n_depots,      vtype=GRB.BINARY, name='X')   # open depot?
        M = model.addVars(n_customers,   vtype=GRB.BINARY, name='M')   # supermarket missed?
        Y = model.addVars(n_depots+1,
                         n_depots+1,    vtype=GRB.BINARY, name='Y')   # tour arcs
        u = model.addVars(n_depots, lb=0, ub=n_depots,
                         vtype=GRB.CONTINUOUS, name='u')             # MTZ ordering

        # objective
        model.setObjective(
            weights['construction'] * gp.quicksum(X[i] for i in range(n_depots))
          + weights['missed_supermarket'] * gp.quicksum(M[j] for j in range(n_customers))
          + weights['travel'] * gp.quicksum(distances[i,j] * Y[i,j] for i in nodes for j in nodes),
            GRB.MINIMIZE
        )

        # 1) service coverage
        for j in range(n_customers):
            model.addConstr(
                gp.quicksum(service[i,j] * X[i] for i in range(n_depots))
              + M[j] >= 1,
                name=f'service_{j}'
            )

        # 2) flow at depot
        model.addConstr(gp.quicksum(Y[0, j+1] for j in range(n_depots)) == 1, name='dep_out')
        model.addConstr(gp.quicksum(Y[i+1, 0] for i in range(n_depots)) == 1, name='dep_in')

        # 3) flow at warehouses
        for i in range(n_depots):
            # if X[i]=1, exactly one arc out of node i+1
            model.addConstr(
                gp.quicksum(Y[i+1, j] for j in nodes if j != i+1) == X[i],
                name=f'flow_out_{i}'
            )
            # if X[i]=1, exactly one arc into node i+1
            model.addConstr(
                gp.quicksum(Y[j, i+1] for j in nodes if j != i+1) == X[i],
                name=f'flow_in_{i}'
            )

        # 4) MTZ subtour elimination
        for i in range(n_depots):
            for j in range(n_depots):
                if i != j:
                    model.addConstr(
                        u[i] - u[j] + n_depots * Y[i+1, j+1] <= n_depots - 1,
                        name=f'mtz_{i}_{j}'
                    )

        # --- solve ---
        model.optimize()

        # --- extract ---
        X_sol = np.array([int(X[i].X + 0.5) for i in range(n_depots)], dtype=int)
        Y_sol = np.zeros((n_depots+1, n_depots+1), dtype=int)
        for i in nodes:
            for j in nodes:
                Y_sol[i, j] = int(Y[i, j].X + 0.5)

        return X_sol, Y_sol
