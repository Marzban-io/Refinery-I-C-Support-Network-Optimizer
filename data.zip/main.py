from instances import *
from environments import *
from solvers import *
from solutions import *

instance_name = 'dummy_problem'

inst = Instance(instance_name)
env  = Environment(inst)

# ← use your custom solver here instead of DummySolver
solver = solver_344864_336623_337876(env)

X, Y = solver.solve()

sol = Solution(X, Y)
sol.write(instance_name)
X, Y = solver.solve()
print("X (build at these depots):", X)
print("Y (arc-incidence matrix):\n", Y)

sol = Solution(X, Y)
sol.write(instance_name)
